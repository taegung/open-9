package com.example.googlemap;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.GroundOverlayOptions;
import com.google.android.gms.maps.model.LatLng;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {
    GoogleMap gMap;  // 구글맵 변수
    MapFragment mapfrag;  // 맵 프래그먼트 변수

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("구글 지도 활용");
        mapfrag = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        mapfrag.getMapAsync(this);
        // activity_main.xml의 fragment를 mapfrag에 대입
    }

    GroundOverlayOptions starmark;


    @Override
    public void onMapReady(GoogleMap map) { // 처음이 보여질
        gMap = map;
        gMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE); //위성지도 설정
        gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(37.568256,126.897240),15));
        //지도 중심을 월드컵경기장(위도:37.~, 경도:126.~)으로 이동하고 확대 레이블 15정도로 함.
        gMap.getUiSettings().setZoomControlsEnabled(true);  // 확대 축소버튼을 아래 보여줌
        gMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() { // 지도클릭 시 작동할 리스너
            @Override
            public void onMapClick(LatLng point) {  // 지도클릭 한다면, (클릭한 위치의 경위도를 LatLng형으로 받음)
                starmark = new GroundOverlayOptions().image(BitmapDescriptorFactory.fromResource(R.drawable.pin))
                        .position(point, 100f, 100f); // 아이콘 생성 , 크기는 100x100 정도로 함
                gMap.addGroundOverlay(starmark); // 아이콘을 지도에 내림
            }
        });
    }

    //메뉴설정
    public boolean onCreateOptionsMenu(Menu menu){
        super.onCreateOptionsMenu(menu);
        menu.add(0,1,0,"위성지도");
        menu.add(0,2,0,"일반지도");
        menu.add(0,3,0,"월드컵경기장 바로가기");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case 1:
                gMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                return true;
            case 2:
                gMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                return true;
            case 3:
                gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(37.568256,126.897240),15));
                //지도 중심을 월드컵경기장(위도:37.~, 경도:126.~)으로 이동하고 확대 레이블 15정도로 함.
                return true;
        }
        return false;
    }
}